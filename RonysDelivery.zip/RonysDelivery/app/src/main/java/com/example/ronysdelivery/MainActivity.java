package com.example.ronysdelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void burgerKing(View view) {
        Intent pagina = new Intent(this, BurgerKing.class);
        startActivity(pagina);
    }

    public void kfc(View view) {
        Intent pagina = new Intent(this, KFC.class);
        startActivity(pagina);
    }

    public void pizzaHut(View view) {
        Intent pagina = new Intent(this, PizzaHut.class);
        startActivity(pagina);
    }
}