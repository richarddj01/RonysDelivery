package com.example.ronysdelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BK_WhopperCombo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bk_whopper_combo);
    }
}